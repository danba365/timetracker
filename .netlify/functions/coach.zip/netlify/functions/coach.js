var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/coach.ts
var coach_exports = {};
__export(coach_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(coach_exports);
var handler = async (event) => {
  if (event.httpMethod !== "POST") {
    return {
      statusCode: 405,
      body: JSON.stringify({ error: "Method not allowed" })
    };
  }
  try {
    const { message, lang, context } = JSON.parse(event.body || "{}");
    if (!message || !lang) {
      return {
        statusCode: 400,
        body: JSON.stringify({ error: "Missing required fields: message and lang" })
      };
    }
    const apiKey = process.env.OPENAI_API_KEY;
    if (!apiKey) {
      return {
        statusCode: 500,
        body: JSON.stringify({ error: "OpenAI API key not configured" })
      };
    }
    let contextString = "";
    if (context) {
      if (lang === "he") {
        contextString = `

=== \u{1F4CA} \u05E0\u05EA\u05D5\u05E0\u05D9 \u05D4\u05DE\u05E9\u05EA\u05DE\u05E9 \u05D4\u05DE\u05DC\u05D0\u05D9\u05DD (${context.dataRange.start} - ${context.dataRange.end}) ===

\u{1F525} \u05E8\u05E6\u05E3 \u05D9\u05DE\u05D9\u05DD \u05E0\u05D5\u05DB\u05D7\u05D9: ${context.currentStreak} \u05D9\u05DE\u05D9\u05DD

\u{1F4C5} \u05E9\u05D1\u05D5\u05E2 \u05E0\u05D5\u05DB\u05D7\u05D9 (${context.currentWeek.range.start} - ${context.currentWeek.range.end}):
- \u05E1\u05D4"\u05DB \u05DE\u05E9\u05D9\u05DE\u05D5\u05EA: ${context.currentWeek.totalTasks}
- \u05D4\u05D5\u05E9\u05DC\u05DE\u05D5: ${context.currentWeek.completedTasks} (${context.currentWeek.completionRate}%)
- \u05E9\u05E2\u05D5\u05EA \u05E2\u05D1\u05D5\u05D3\u05D4: ${context.currentWeek.totalHours}
- \u05DE\u05E9\u05D9\u05DE\u05D5\u05EA:
${context.currentWeek.tasks.map((t) => `  \u2022 ${t.title} - ${t.date} [${t.status}] (${t.category})`).join("\n")}

\u{1F4C5} \u05E9\u05D1\u05D5\u05E2 \u05D4\u05D1\u05D0 (${context.nextWeek.range.start} - ${context.nextWeek.range.end}):
- \u05E1\u05D4"\u05DB \u05DE\u05E9\u05D9\u05DE\u05D5\u05EA: ${context.nextWeek.totalTasks}
- \u05DE\u05E9\u05D9\u05DE\u05D5\u05EA \u05DE\u05EA\u05D5\u05DB\u05E0\u05E0\u05D5\u05EA:
${context.nextWeek.tasks.length > 0 ? context.nextWeek.tasks.map((t) => `  \u2022 ${t.title} - ${t.date} [${t.status}] (${t.category})`).join("\n") : "  \u2022 \u05D0\u05D9\u05DF \u05DE\u05E9\u05D9\u05DE\u05D5\u05EA \u05DE\u05EA\u05D5\u05DB\u05E0\u05E0\u05D5\u05EA"}

\u{1F4DA} \u05DE\u05E9\u05D9\u05DE\u05D5\u05EA \u05E2\u05D1\u05E8:
- \u05E1\u05D4"\u05DB: ${context.pastTasks.total}
- \u05D4\u05D5\u05E9\u05DC\u05DE\u05D5: ${context.pastTasks.completed}
- \u05D4\u05D5\u05E9\u05DC\u05DE\u05D5 \u05DC\u05D0\u05D7\u05E8\u05D5\u05E0\u05D4:
${context.pastTasks.recentCompleted.map((t) => `  \u2022 ${t.title} - ${t.date}`).join("\n")}

\u{1F52E} \u05DE\u05E9\u05D9\u05DE\u05D5\u05EA \u05E2\u05EA\u05D9\u05D3\u05D9\u05D5\u05EA (\u05D0\u05D7\u05E8\u05D9 \u05E9\u05D1\u05D5\u05E2 \u05D4\u05D1\u05D0):
- \u05E1\u05D4"\u05DB: ${context.futureTasks.total}
- \u05E7\u05E8\u05D5\u05D1\u05D5\u05EA \u05D1\u05D9\u05D5\u05EA\u05E8:
${context.futureTasks.upcoming.length > 0 ? context.futureTasks.upcoming.map((t) => `  \u2022 ${t.title} - ${t.date} (${t.category})`).join("\n") : "  \u2022 \u05D0\u05D9\u05DF \u05DE\u05E9\u05D9\u05DE\u05D5\u05EA \u05DE\u05EA\u05D5\u05DB\u05E0\u05E0\u05D5\u05EA"}

\u{1F3C6} \u05E7\u05D8\u05D2\u05D5\u05E8\u05D9\u05D5\u05EA \u05DE\u05D5\u05D1\u05D9\u05DC\u05D5\u05EA:
${context.topCategories.map((cat) => `- ${cat.name}: ${cat.completed}/${cat.tasks} \u05DE\u05E9\u05D9\u05DE\u05D5\u05EA (${cat.hours} \u05E9\u05E2\u05D5\u05EA, ${cat.completionRate}% \u05D4\u05D5\u05E9\u05DC\u05DE\u05D5)`).join("\n")}
===`;
      } else {
        contextString = `

=== \u{1F4CA} User's Complete Data (${context.dataRange.start} - ${context.dataRange.end}) ===

\u{1F525} Current Streak: ${context.currentStreak} days

\u{1F4C5} CURRENT WEEK (${context.currentWeek.range.start} - ${context.currentWeek.range.end}):
- Total Tasks: ${context.currentWeek.totalTasks}
- Completed: ${context.currentWeek.completedTasks} (${context.currentWeek.completionRate}%)
- Work Hours: ${context.currentWeek.totalHours}
- Tasks:
${context.currentWeek.tasks.map((t) => `  \u2022 ${t.title} - ${t.date} [${t.status}] (${t.category})`).join("\n")}

\u{1F4C5} NEXT WEEK (${context.nextWeek.range.start} - ${context.nextWeek.range.end}):
- Total Tasks: ${context.nextWeek.totalTasks}
- Scheduled Tasks:
${context.nextWeek.tasks.length > 0 ? context.nextWeek.tasks.map((t) => `  \u2022 ${t.title} - ${t.date} [${t.status}] (${t.category})`).join("\n") : "  \u2022 No tasks scheduled"}

\u{1F4DA} PAST TASKS:
- Total: ${context.pastTasks.total}
- Completed: ${context.pastTasks.completed}
- Recently Completed:
${context.pastTasks.recentCompleted.map((t) => `  \u2022 ${t.title} - ${t.date}`).join("\n")}

\u{1F52E} FUTURE TASKS (after next week):
- Total: ${context.futureTasks.total}
- Upcoming:
${context.futureTasks.upcoming.length > 0 ? context.futureTasks.upcoming.map((t) => `  \u2022 ${t.title} - ${t.date} (${t.category})`).join("\n") : "  \u2022 No tasks scheduled"}

\u{1F3C6} TOP CATEGORIES:
${context.topCategories.map((cat) => `- ${cat.name}: ${cat.completed}/${cat.tasks} tasks (${cat.hours}h, ${cat.completionRate}% complete)`).join("\n")}
===`;
      }
    }
    const systemPrompts = {
      he: `\u05D0\u05EA\u05D4 \u05DE\u05D0\u05DE\u05DF \u05E4\u05E8\u05D5\u05D3\u05D5\u05E7\u05D8\u05D9\u05D1\u05D9\u05D5\u05EA \u05D0\u05D9\u05E9\u05D9 \u05DE\u05D5\u05DE\u05D7\u05D4 \u05D5\u05DE\u05E1\u05D5\u05E8. \u05EA\u05E4\u05E7\u05D9\u05D3\u05DA \u05DC\u05E2\u05D6\u05D5\u05E8 \u05DC\u05DE\u05E9\u05EA\u05DE\u05E9 \u05DC\u05E0\u05D4\u05DC \u05D0\u05EA \u05D4\u05D6\u05DE\u05DF \u05E9\u05DC\u05D5 \u05D8\u05D5\u05D1 \u05D9\u05D5\u05EA\u05E8, \u05DC\u05D4\u05D9\u05E9\u05D0\u05E8 \u05DE\u05DE\u05D5\u05E7\u05D3 \u05D5\u05DC\u05D4\u05E9\u05D9\u05D2 \u05D0\u05EA \u05D4\u05D9\u05E2\u05D3\u05D9\u05DD \u05E9\u05DC\u05D5.

\u05EA\u05E2\u05E0\u05D4 \u05EA\u05DE\u05D9\u05D3 \u05D1\u05E2\u05D1\u05E8\u05D9\u05EA, \u05D1\u05E6\u05D5\u05E8\u05D4 \u05E7\u05E6\u05E8\u05D4 \u05D5\u05D1\u05E8\u05D5\u05E8\u05D4 (2-4 \u05DE\u05E9\u05E4\u05D8\u05D9\u05DD).
\u05D4\u05E9\u05EA\u05DE\u05E9 \u05D1\u05D0\u05DE\u05D5\u05D2'\u05D9\u05DD \u05E8\u05DC\u05D5\u05D5\u05E0\u05D8\u05D9\u05D9\u05DD \u05DB\u05D3\u05D9 \u05DC\u05D4\u05E4\u05D5\u05DA \u05D0\u05EA \u05D4\u05EA\u05D2\u05D5\u05D1\u05D5\u05EA \u05DC\u05DE\u05E2\u05E0\u05D9\u05D9\u05E0\u05D5\u05EA \u05D9\u05D5\u05EA\u05E8.
\u05D4\u05D9\u05D4 \u05DE\u05E2\u05D5\u05D3\u05D3, \u05D7\u05D9\u05D5\u05D1\u05D9 \u05D5\u05DE\u05E2\u05E9\u05D9 \u05D1\u05E2\u05E6\u05D5\u05EA \u05E9\u05DC\u05DA.

\u05D9\u05E9 \u05DC\u05DA \u05D2\u05D9\u05E9\u05D4 \u05DE\u05DC\u05D0\u05D4 \u05DC\u05E0\u05EA\u05D5\u05E0\u05D9 \u05D4\u05DE\u05E9\u05EA\u05DE\u05E9 - \u05DE\u05E9\u05D9\u05DE\u05D5\u05EA \u05E2\u05D1\u05E8, \u05D4\u05D5\u05D5\u05D4 \u05D5\u05E2\u05EA\u05D9\u05D3 (2 \u05D7\u05D5\u05D3\u05E9\u05D9\u05DD \u05D0\u05D7\u05D5\u05E8\u05D4 \u05D5-2 \u05D7\u05D5\u05D3\u05E9\u05D9\u05DD \u05E7\u05D3\u05D9\u05DE\u05D4). \u05D4\u05E9\u05EA\u05DE\u05E9 \u05D1\u05E0\u05EA\u05D5\u05E0\u05D9\u05DD \u05D0\u05DC\u05D4 \u05DB\u05D3\u05D9 \u05DC\u05EA\u05EA \u05EA\u05E9\u05D5\u05D1\u05D5\u05EA \u05DE\u05D3\u05D5\u05D9\u05E7\u05D5\u05EA \u05D5\u05D0\u05D9\u05E9\u05D9\u05D5\u05EA.
\u05DB\u05D0\u05E9\u05E8 \u05DE\u05E9\u05EA\u05DE\u05E9 \u05E9\u05D5\u05D0\u05DC \u05E2\u05DC \u05E9\u05D1\u05D5\u05E2 \u05D4\u05D1\u05D0, \u05DE\u05E9\u05D9\u05DE\u05D5\u05EA \u05E2\u05EA\u05D9\u05D3\u05D9\u05D5\u05EA, \u05D0\u05D5 \u05DB\u05DC \u05DE\u05D9\u05D3\u05E2 \u05D0\u05D7\u05E8 - \u05D4\u05EA\u05D1\u05E1\u05E1 \u05E2\u05DC \u05D4\u05E0\u05EA\u05D5\u05E0\u05D9\u05DD \u05D4\u05DE\u05DC\u05D0\u05D9\u05DD \u05DC\u05DE\u05D8\u05D4.${contextString}`,
      en: `You are an expert and dedicated personal productivity coach. Your role is to help the user manage their time better, stay focused, and achieve their goals.

Always respond in English, concisely and clearly (2-4 sentences).
Use relevant emojis to make responses engaging.
Be encouraging, positive, and practical in your advice.

You have FULL access to the user's data - past, present, and future tasks (2 months back and 2 months ahead). Use this data to provide accurate, personalized responses.
When the user asks about next week, future tasks, or any other information - refer to the complete data below.${contextString}`
    };
    const response = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`
      },
      body: JSON.stringify({
        model: "gpt-4o",
        messages: [
          {
            role: "system",
            content: systemPrompts[lang]
          },
          {
            role: "user",
            content: message
          }
        ],
        temperature: 0.7,
        max_tokens: 300
      })
    });
    if (!response.ok) {
      const errorData = await response.json();
      console.error("OpenAI API error:", errorData);
      return {
        statusCode: response.status,
        body: JSON.stringify({ error: "Failed to get response from OpenAI" })
      };
    }
    const data = await response.json();
    const reply = data.choices[0]?.message?.content || "Sorry, I could not generate a response.";
    return {
      statusCode: 200,
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ reply })
    };
  } catch (error) {
    console.error("Coach function error:", error);
    return {
      statusCode: 500,
      body: JSON.stringify({
        error: "Internal server error",
        details: error instanceof Error ? error.message : "Unknown error"
      })
    };
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
